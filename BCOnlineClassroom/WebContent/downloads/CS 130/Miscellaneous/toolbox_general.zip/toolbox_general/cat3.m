function c = cat3(d, a,b)

% cat3 - synonymous with cat

c = cat(d,a,b);
